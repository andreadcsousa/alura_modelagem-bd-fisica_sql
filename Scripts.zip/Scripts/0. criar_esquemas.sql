# Criando um esquema (uma base de dados)
# Create: criar esquemas, tabelas tipos, dominios, views, triggers entre outros..
# Esquema: Entidade que agrupa tabelas pertecentes a mesma aplicação

# 1. identidficar se o banco de dados está no ar.
# 2. MYSQL Workbench e clicar na conexão criada na preparação do ambiente
# 3. Clicar em "Schema" na parte de baixo de "Navigator"

CREATE SCHEMA CLUBE_DO_LIVRO;


# 4. Seleciona o comando
# 5. Apertar no raiozinho para executar o código
# 6. E atualizar a visualização no botão de setinhas em "Schema" na parte de baixo de "Navigator"




